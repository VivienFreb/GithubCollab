# Exercice de fusion de branches

## Contexte
Ceci est un projet fictif d'une entreprise. Une page de login a été développée par votre collègue. Celui-ci vous demande de rajouter la connexion via les réseaux sociaux (Google, LinkedIn...). Vous avez donc créé une branche séparée pour faire votre fonctionnalité appelée "adding-social". Vous avez également ajouté le code nécessaire pour ajouter cette partie et vous avez également effectué les commandes git nécessaires (add, commit...).

## Objectif
Désormais, on vous demande si vous pouvez intégrer les modifications apportées dans cette branche dans la branche "master" de l'application.

## Instructions
Essayez d'intégrer les modifications à cette branche "master". On vous demandera généralement d'effacer cette branche après avoir effectué vos modifications. 

## Bonus
L'erreur est humaine, cherchez également comment revenir à l'état d'avant votre fusion, ça peut être utile.